This zip contains code from every chapter the book 
with the exception of chapters 1, 2, 9, 13, 14, and 17. 

Chapters 4, 5, 6, 8, and 10-12 have downloads on the 
www.wrox.com/go/proaspnetmvc5 web site, which are contained 
in this zip file.

You will find all the code for Chapters 3, 7, 15 and 16 via NuGet. 
The NuGet packages are also available at 
http://www.wrox.com/go/proaspmvc5 for offline use. The NuGet
packages for this book are as follows:
Wrox.ProMvc5.ExtendingMvc.1.0.0.nupkg         
Wrox.ProMvc5.Security.Authorize.1.0.0.nupkg   
Wrox.ProMvc5.Views.AlbumList.1.0.0.0.nupkg    
Wrox.ProMvc5.Views.BasePageType.1.0.0.nupkg   
Wrox.ProMvc5.Views.SpecifyingViews.1.0.0.nupkg
Wrox.ProMvc5.Views.ViewModel.1.0.0.nupkg

In general, we've opted for NuGet code samples for smaller, 
self-contained code. Others examples require a complete project
with sample data, configuration, etc. and make more sense as
zipped project dowloads.

Please also note that in some cases, certain examples or listings 
from the chapters are not included because the example is generated 
code, output, or something you would never enter yourself. We hope 
you have fun with the sample code we have included and that you find
 it useful and informative. Enjoy.